def classFactory(iface):
    from .color_changer import ColorChanger
    return ColorChanger(iface)