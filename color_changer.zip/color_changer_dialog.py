# -*- coding: utf-8 -*-

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtWidgets import QMessageBox, QColorDialog
from qgis.PyQt.QtGui import QColor

from qgis.core import (
    QgsProject,
    QgsVectorLayer
)

import os


FORM_CLASS, _ = uic.loadUiType(
    os.path.join(
        os.path.dirname(__file__),
        'color_changer_dialog_base.ui'
    )
)


class ColorChangerDialog(QtWidgets.QDialog, FORM_CLASS):

    def __init__(self, parent=None):
        super(ColorChangerDialog, self).__init__(parent)

        self.setupUi(self)
        self.init_components()

    def init_components(self):
        self.refresh_layer_combo()

        self.comboLayer.currentIndexChanged.connect(
            self.on_layer_changed
        )

        self.applyButton.clicked.connect(
            self.change_feature_color
        )


    def refresh_layer_combo(self):
        #Загрузить слои в комбобокс
        self.comboLayer.clear()

        layers = QgsProject.instance().mapLayers().values()

        for layer in layers:
            if isinstance(layer, QgsVectorLayer):
                self.comboLayer.addItem(
                    layer.name(),
                    layer
                )

        self.on_layer_changed()

    def current_layer(self):
        return self.comboLayer.currentData()


    def on_layer_changed(self): #триггер 
        self.update_feature_combo()

    def update_feature_combo(self):
        #Загрузка объектов слоя в комбобокс
        self.comboFeature.clear()

        layer = self.current_layer()

        if not layer:
            return

        display_field = self.get_display_field(layer)

        for feat in layer.getFeatures():

            if display_field:
                value = feat[display_field]
                text = f"{value} (ID: {feat.id()})"
            else:
                text = f"ID: {feat.id()}"

            self.comboFeature.addItem(
                text,
                feat.id()
            )

    def get_display_field(self, layer):

        fields = layer.fields()

        for name in ['name', 'Name', 'название', 'type']:

            if fields.indexFromName(name) != -1:
                return name

        for field in fields:

            if field.typeName() in ['QString', 'String']:
                return field.name()

        return None

    def current_feature_id(self):
        return self.comboFeature.currentData()


    def change_feature_color(self):
        #Изменяем поле color для таблицы атрибутов
        
        layer = self.current_layer()

        if not layer:
            QMessageBox.warning(
                self,
                "Ошибка",
                "Выберите слой."
            )
            return

        fid = self.current_feature_id()

        if fid is None:
            QMessageBox.warning(
                self,
                "Ошибка",
                "Выберите объект."
            )
            return

        # Проверяем поле color
        color_field_idx = layer.fields().indexFromName("color")

        if color_field_idx == -1: #Индекс -1 = поле отсутствует
            QMessageBox.warning(
                self,
                "Ошибка",
                "В слое отсутствует поле 'color'."
            )
            return

        # Выбор цвета через встроенный интерфейс
        selected_color = QColorDialog.getColor()

        if not selected_color.isValid():
            return

        color_hex = selected_color.name()

        # Редактирование слоя
        if not layer.isEditable():
            layer.startEditing()

        success = layer.changeAttributeValue(
            fid,
            color_field_idx,
            color_hex
        )

        if not success:
            layer.rollBack()

            QMessageBox.critical(
                self,
                "Ошибка",
                "Не удалось изменить атрибут."
            )
            return

        commit_result = layer.commitChanges()

        if not commit_result:

            layer.rollBack()

            QMessageBox.critical(
                self,
                "Ошибка",
                "Ошибка сохранения изменений."
            )

            return

        # Обновление отображения
        layer.triggerRepaint()

        iface = self.parent().iface if self.parent() else None

        if iface:
            iface.layerTreeView().refreshLayerSymbology(
                layer.id()
            )

        QMessageBox.information(
            self,
            "Успех",
            f"Цвет объекта изменён на {color_hex}"
        )